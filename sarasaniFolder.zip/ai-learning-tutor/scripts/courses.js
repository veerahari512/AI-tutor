// Courses functionality
document.addEventListener('DOMContentLoaded', function() {
    initializeCourses();
});

function initializeCourses() {
    // Check if user is logged in
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    if (!currentUser && window.location.pathname.includes('courses.html')) {
        // Allow browsing courses without login, but show login prompt for enrollment
    }
    
    // Load courses
    loadCourses();
    
    // Setup filter buttons
    setupFilters();
    
    // Setup search functionality
    setupSearch();
}

// Sample course data
const coursesData = [
    {
        id: 1,
        title: "Python Programming Masterclass",
        description: "Learn Python from scratch to advanced level with hands-on projects and real-world applications.",
        category: "programming",
        duration: "42 hours",
        level: "Beginner to Advanced",
        students: 15420,
        progress: 0,
        icon: "fab fa-python",
        imageColor: "#3776AB",
        instructor: "Dr. Sarah Johnson",
        rating: 4.8,
        lessons: 56,
        projects: 12
    },
    {
        id: 2,
        title: "Data Science with Python",
        description: "Master data analysis, visualization, and machine learning using Python and popular libraries.",
        category: "data-science",
        duration: "36 hours",
        level: "Intermediate",
        students: 8920,
        progress: 0,
        icon: "fas fa-chart-bar",
        imageColor: "#4CC9F0",
        instructor: "Prof. Michael Chen",
        rating: 4.7,
        lessons: 48,
        projects: 8
    },
    {
        id: 3,
        title: "Full Stack Web Development",
        description: "Build modern web applications with React, Node.js, and MongoDB from frontend to backend.",
        category: "web-dev",
        duration: "54 hours",
        level: "Beginner to Advanced",
        students: 12350,
        progress: 0,
        icon: "fas fa-code",
        imageColor: "#F72585",
        instructor: "Alex Rodriguez",
        rating: 4.9,
        lessons: 72,
        projects: 15
    },
    {
        id: 4,
        title: "JavaScript Fundamentals",
        description: "Comprehensive JavaScript course covering ES6+ features, DOM manipulation, and async programming.",
        category: "programming",
        duration: "28 hours",
        level: "Beginner",
        students: 18760,
        progress: 0,
        icon: "fab fa-js-square",
        imageColor: "#F7DF1E",
        instructor: "Emily Watson",
        rating: 4.6,
        lessons: 35,
        projects: 6
    },
    {
        id: 5,
        title: "Machine Learning Basics",
        description: "Introduction to machine learning concepts, algorithms, and practical implementations.",
        category: "data-science",
        duration: "32 hours",
        level: "Intermediate",
        students: 7450,
        progress: 0,
        icon: "fas fa-robot",
        imageColor: "#7209B7",
        instructor: "Dr. James Wilson",
        rating: 4.8,
        lessons: 40,
        projects: 7
    },
    {
        id: 6,
        title: "UI/UX Design Principles",
        description: "Learn user interface and experience design principles for creating engaging digital products.",
        category: "design",
        duration: "24 hours",
        level: "Beginner",
        students: 9320,
        progress: 0,
        icon: "fas fa-paint-brush",
        imageColor: "#4361EE",
        instructor: "Lisa Thompson",
        rating: 4.7,
        lessons: 30,
        projects: 5
    },
    {
        id: 7,
        title: "Business Analytics",
        description: "Data-driven decision making and business intelligence techniques for modern organizations.",
        category: "business",
        duration: "30 hours",
        level: "Intermediate",
        students: 5680,
        progress: 0,
        icon: "fas fa-chart-line",
        imageColor: "#4BB543",
        instructor: "Robert Kim",
        rating: 4.5,
        lessons: 38,
        projects: 6
    },
    {
        id: 8,
        title: "Mobile App Development",
        description: "Build cross-platform mobile applications using React Native and modern development tools.",
        category: "web-dev",
        duration: "38 hours",
        level: "Intermediate",
        students: 6780,
        progress: 0,
        icon: "fas fa-mobile-alt",
        imageColor: "#3A0CA3",
        instructor: "David Park",
        rating: 4.6,
        lessons: 45,
        projects: 8
    }
];

function loadCourses(category = 'all', searchTerm = '') {
    const coursesGrid = document.getElementById('courses-grid');
    
    // Filter courses based on category and search term
    let filteredCourses = coursesData;
    
    if (category !== 'all') {
        filteredCourses = filteredCourses.filter(course => course.category === category);
    }
    
    if (searchTerm) {
        filteredCourses = filteredCourses.filter(course => 
            course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            course.description.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }
    
    if (filteredCourses.length === 0) {
        coursesGrid.innerHTML = `
            <div class="no-courses">
                <i class="fas fa-search"></i>
                <h3>No courses found</h3>
                <p>Try adjusting your search or filter criteria</p>
            </div>
        `;
        return;
    }
    
    coursesGrid.innerHTML = '';
    
    filteredCourses.forEach(course => {
        const courseCard = createCourseCard(course);
        coursesGrid.appendChild(courseCard);
    });
}

function createCourseCard(course) {
    const courseCard = document.createElement('div');
    courseCard.className = 'course-card';
    courseCard.setAttribute('data-course-id', course.id);
    
    // Check if user is enrolled in this course
    const userCourses = JSON.parse(localStorage.getItem('userCourses') || '[]');
    const isEnrolled = userCourses.includes(course.id);
    
    let progressHTML = '';
    let buttonHTML = '';
    
    if (isEnrolled) {
        const userProgress = JSON.parse(localStorage.getItem('userProgress') || '{}');
        const progress = userProgress[course.id] || 0;
        
        progressHTML = `
            <div class="course-progress">
                <div class="progress-info">
                    <span>Progress</span>
                    <span>${progress}%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${progress}%"></div>
                </div>
            </div>
        `;
        
        buttonHTML = `
            <button class="btn btn-primary btn-small w-100" onclick="continueCourse(${course.id})">
                <i class="fas fa-play-circle"></i>
                Continue Learning
            </button>
        `;
    } else {
        buttonHTML = `
            <button class="btn btn-primary btn-small w-100" onclick="enrollInCourse(${course.id})">
                <i class="fas fa-plus"></i>
                Enroll Now
            </button>
        `;
    }
    
    courseCard.innerHTML = `
        <div class="course-image" style="background: linear-gradient(135deg, ${course.imageColor}, ${course.imageColor}99);">
            <i class="${course.icon}"></i>
        </div>
        <div class="course-content">
            <span class="course-category">${getCategoryName(course.category)}</span>
            <h3 class="course-title">${course.title}</h3>
            <p class="course-description">${course.description}</p>
            
            <div class="course-meta">
                <div class="course-duration">
                    <i class="fas fa-clock"></i>
                    <span>${course.duration}</span>
                </div>
                <div class="course-level">
                    <i class="fas fa-signal"></i>
                    <span>${course.level}</span>
                </div>
                <div class="enrollment-stats">
                    <i class="fas fa-users"></i>
                    <span>${course.students.toLocaleString()}</span>
                </div>
            </div>
            
            ${progressHTML}
            
            <div class="course-instructor">
                <small>Instructor: ${course.instructor}</small>
            </div>
            
            <div class="course-rating" style="margin: 10px 0;">
                <i class="fas fa-star" style="color: #FFCC00;"></i>
                <span>${course.rating}</span>
                <small style="color: var(--gray-light);">(${Math.floor(course.students / 10).toLocaleString()} reviews)</small>
            </div>
            
            ${buttonHTML}
        </div>
    `;
    
    return courseCard;
}

function getCategoryName(category) {
    const categories = {
        'programming': 'Programming',
        'data-science': 'Data Science',
        'web-dev': 'Web Development',
        'business': 'Business',
        'design': 'Design'
    };
    return categories[category] || category;
}

function setupFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Load courses for selected category
            const category = this.getAttribute('data-category');
            loadCourses(category);
        });
    });
}

function setupSearch() {
    const searchInput = document.getElementById('course-search');
    
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value;
        const activeCategory = document.querySelector('.filter-btn.active').getAttribute('data-category');
        loadCourses(activeCategory, searchTerm);
    });
}

function enrollInCourse(courseId) {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    if (!currentUser) {
        showNotification('Please log in to enroll in courses', 'warning');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 2000);
        return;
    }
    
    const userCourses = JSON.parse(localStorage.getItem('userCourses') || '[]');
    
    if (!userCourses.includes(courseId)) {
        userCourses.push(courseId);
        localStorage.setItem('userCourses', JSON.stringify(userCourses));
        
        // Initialize progress for this course
        const userProgress = JSON.parse(localStorage.getItem('userProgress') || '{}');
        userProgress[courseId] = 0;
        localStorage.setItem('userProgress', JSON.stringify(userProgress));
        
        showNotification('Successfully enrolled in course!', 'success');
        
        // Reload courses to show updated state
        setTimeout(() => {
            loadCourses();
        }, 1000);
    } else {
        showNotification('You are already enrolled in this course', 'info');
    }
}

function continueCourse(courseId) {
    // Redirect to course learning page or dashboard
    showNotification('Redirecting to course...', 'success');
    setTimeout(() => {
        window.location.href = 'dashboard.html';
    }, 1500);
}

function showNotification(message, type = 'success') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create new notification
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Auto hide after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
}