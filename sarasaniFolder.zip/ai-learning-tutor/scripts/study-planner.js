// Study Planner functionality
document.addEventListener('DOMContentLoaded', function() {
    initializeStudyPlanner();
});

function initializeStudyPlanner() {
    // Check if user is logged in
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    if (!currentUser) {
        showNotification('Please log in to use the study planner', 'warning');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 2000);
        return;
    }
    
    // Load saved plans
    loadSavedPlans();
    
    // Setup chat functionality
    setupChat();
}

// Sample study plans data
const studyPlans = {
    python: {
        title: "Python Programming Roadmap",
        description: "A comprehensive 12-week learning path from Python basics to advanced concepts",
        duration: "12 weeks",
        hours: "84 hours total",
        timeline: [
            {
                week: "Week 1-2",
                title: "Python Basics",
                description: "Learn fundamental Python syntax, variables, data types, and basic operations",
                resources: ["Python Official Tutorial", "Interactive Coding Exercises", "Basic Projects"]
            },
            {
                week: "Week 3-4",
                title: "Control Structures & Functions",
                description: "Master conditionals, loops, and function definitions with practical exercises",
                resources: ["Function Practice Problems", "Code Challenges", "Mini Projects"]
            },
            {
                week: "Week 5-6",
                title: "Data Structures",
                description: "Understand lists, dictionaries, tuples, sets and their practical applications",
                resources: ["Data Structure Exercises", "Algorithm Practice", "Real-world Examples"]
            },
            {
                week: "Week 7-8",
                title: "Object-Oriented Programming",
                description: "Learn classes, objects, inheritance, and polymorphism in Python",
                resources: ["OOP Tutorials", "Class Design Exercises", "Inheritance Practice"]
            },
            {
                week: "Week 9-10",
                title: "File Handling & Modules",
                description: "Work with files, import modules, and understand package management",
                resources: ["File I/O Exercises", "Module Practice", "Package Projects"]
            },
            {
                week: "Week 11-12",
                title: "Advanced Topics & Final Project",
                description: "Explore error handling, decorators, and build a capstone project",
                resources: ["Advanced Concepts", "Final Project Ideas", "Portfolio Building"]
            }
        ]
    },
    javascript: {
        title: "JavaScript Learning Path",
        description: "From JavaScript fundamentals to modern ES6+ features and web development",
        duration: "10 weeks",
        hours: "70 hours total",
        timeline: [
            {
                week: "Week 1-2",
                title: "JavaScript Basics",
                description: "Learn variables, data types, operators, and basic syntax",
                resources: ["MDN JavaScript Guide", "Basic Exercises", "Console Practice"]
            },
            {
                week: "Week 3-4",
                title: "Functions & Control Flow",
                description: "Master function declarations, expressions, conditionals, and loops",
                resources: ["Function Exercises", "Logic Problems", "Interactive Challenges"]
            },
            {
                week: "Week 5-6",
                title: "DOM Manipulation",
                description: "Learn to select elements, handle events, and create dynamic content",
                resources: ["DOM Practice", "Event Handling", "Dynamic Web Pages"]
            },
            {
                week: "Week 7-8",
                title: "ES6+ Features",
                description: "Explore arrow functions, destructuring, template literals, and modules",
                resources: ["Modern JavaScript", "ES6 Exercises", "Module Practice"]
            },
            {
                week: "Week 9-10",
                title: "Async JavaScript & Projects",
                description: "Understand callbacks, promises, async/await and build final projects",
                resources: ["Async Exercises", "API Projects", "Portfolio Development"]
            }
        ]
    }
};

function loadSavedPlans() {
    const savedPlansContainer = document.getElementById('saved-plans');
    const userPlans = JSON.parse(localStorage.getItem('userStudyPlans') || '[]');
    
    if (userPlans.length === 0) {
        savedPlansContainer.innerHTML = `
            <div class="no-plan">
                <p>No saved plans yet. Create your first one!</p>
            </div>
        `;
        return;
    }
    
    savedPlansContainer.innerHTML = '';
    
    userPlans.forEach(plan => {
        const planItem = document.createElement('div');
        planItem.className = 'plan-item';
        planItem.innerHTML = `
            <h4>${plan.subject}</h4>
            <p>Created ${new Date(plan.createdAt).toLocaleDateString()}</p>
        `;
        
        planItem.addEventListener('click', () => {
            displayStudyPlan(plan);
        });
        
        savedPlansContainer.appendChild(planItem);
    });
}

function setupChat() {
    const userInput = document.getElementById('user-input');
    
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
}

function sendMessage() {
    const userInput = document.getElementById('user-input');
    const message = userInput.value.trim();
    
    if (message === '') return;
    
    // Add user message to chat
    addMessage(message, 'user');
    userInput.value = '';
    
    // Process message and generate response
    setTimeout(() => {
        processUserMessage(message);
    }, 1000);
}

function sendSuggestion(subject) {
    const userInput = document.getElementById('user-input');
    userInput.value = `I want to learn ${subject}`;
    sendMessage();
}

function addMessage(content, sender) {
    const chatMessages = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    
    messageDiv.innerHTML = `
        <div class="message-content">
            <p>${content}</p>
        </div>
    `;
    
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function processUserMessage(message) {
    const lowerMessage = message.toLowerCase();
    
    // Check for common subjects
    if (lowerMessage.includes('python')) {
        generateStudyPlan('python');
    } else if (lowerMessage.includes('javascript') || lowerMessage.includes('js')) {
        generateStudyPlan('javascript');
    } else if (lowerMessage.includes('data science') || lowerMessage.includes('machine learning')) {
        addMessage("I can create a Data Science study plan for you! This would include Python, statistics, and machine learning concepts. Would you like me to generate a detailed plan?", 'bot');
    } else if (lowerMessage.includes('web development') || lowerMessage.includes('web dev')) {
        addMessage("Great choice! I can create a comprehensive web development roadmap covering HTML, CSS, JavaScript, and frameworks. Should I generate a personalized plan for you?", 'bot');
    } else {
        addMessage("I'd be happy to create a study plan for you! Please specify what subject you'd like to learn. For example: 'Python', 'JavaScript', 'Data Science', or 'Web Development'.", 'bot');
    }
}

function generateStudyPlan(subject) {
    const plan = studyPlans[subject];
    
    if (!plan) {
        addMessage("I don't have a pre-built plan for that subject yet, but I can create a custom one for you! Please describe what you'd like to learn in more detail.", 'bot');
        return;
    }
    
    // Save plan to user's saved plans
    saveStudyPlan(subject, plan);
    
    // Display the plan
    displayStudyPlan({ subject, plan });
    
    addMessage(`I've created a personalized ${subject} study plan for you! Check it out below.`, 'bot');
}

function saveStudyPlan(subject, plan) {
    const userPlans = JSON.parse(localStorage.getItem('userStudyPlans') || '[]');
    
    const planData = {
        id: 'plan_' + Date.now(),
        subject: subject,
        plan: plan,
        createdAt: new Date().toISOString(),
        progress: 0
    };
    
    // Check if plan already exists
    const existingPlanIndex = userPlans.findIndex(p => p.subject === subject);
    if (existingPlanIndex !== -1) {
        userPlans[existingPlanIndex] = planData;
    } else {
        userPlans.push(planData);
    }
    
    localStorage.setItem('userStudyPlans', JSON.stringify(userPlans));
    
    // Reload saved plans
    loadSavedPlans();
}

function displayStudyPlan(planData) {
    const chatInterface = document.getElementById('chat-interface');
    const studyPlan = document.getElementById('study-plan');
    const plan = planData.plan;
    
    // Hide chat and show study plan
    chatInterface.style.display = 'none';
    studyPlan.innerHTML = '';
    studyPlan.classList.add('active');
    
    // Create plan header
    const planHeader = document.createElement('div');
    planHeader.className = 'plan-header';
    planHeader.innerHTML = `
        <h2>${plan.title}</h2>
        <p>${plan.description}</p>
        <div style="display: flex; justify-content: center; gap: 20px; margin-top: 15px;">
            <span><i class="fas fa-clock"></i> ${plan.duration}</span>
            <span><i class="fas fa-hourglass-half"></i> ${plan.hours}</span>
        </div>
    `;
    studyPlan.appendChild(planHeader);
    
    // Create timeline
    const timeline = document.createElement('div');
    timeline.className = 'plan-timeline';
    
    plan.timeline.forEach((item, index) => {
        const timelineItem = document.createElement('div');
        timelineItem.className = 'timeline-item';
        
        const marker = document.createElement('div');
        marker.className = 'timeline-marker';
        marker.innerHTML = `<span>${index + 1}</span>`;
        
        const content = document.createElement('div');
        content.className = 'timeline-content';
        
        let resourcesHTML = '';
        if (item.resources && item.resources.length > 0) {
            resourcesHTML = `
                <div class="resources">
                    <h4>Learning Resources:</h4>
                    <div class="resource-list">
                        ${item.resources.map(resource => `<div class="resource-item">${resource}</div>`).join('')}
                    </div>
                </div>
            `;
        }
        
        content.innerHTML = `
            <h3>${item.week}: ${item.title}</h3>
            <p>${item.description}</p>
            ${resourcesHTML}
        `;
        
        timelineItem.appendChild(marker);
        timelineItem.appendChild(content);
        timeline.appendChild(timelineItem);
    });
    
    studyPlan.appendChild(timeline);
    
    // Add action buttons
    const actionDiv = document.createElement('div');
    actionDiv.style.textAlign = 'center';
    actionDiv.style.marginTop = '30px';
    actionDiv.style.paddingTop = '20px';
    actionDiv.style.borderTop = '1px solid #e9ecef';
    actionDiv.innerHTML = `
        <button class="btn btn-primary" onclick="startThisPlan('${planData.subject}')">
            <i class="fas fa-play-circle"></i>
            Start This Plan
        </button>
        <button class="btn btn-secondary" onclick="backToChat()">
            <i class="fas fa-arrow-left"></i>
            Back to Chat
        </button>
    `;
    studyPlan.appendChild(actionDiv);
}

function startThisPlan(subject) {
    showNotification(`Starting your ${subject} study plan! Redirecting to dashboard...`, 'success');
    
    // In a real app, this would set the plan as active and redirect
    setTimeout(() => {
        window.location.href = 'dashboard.html';
    }, 2000);
}

function backToChat() {
    const chatInterface = document.getElementById('chat-interface');
    const studyPlan = document.getElementById('study-plan');
    
    chatInterface.style.display = 'block';
    studyPlan.classList.remove('active');
    studyPlan.innerHTML = '';
}

function startNewPlan() {
    backToChat();
    
    // Clear any existing messages except the first bot message
    const chatMessages = document.getElementById('chat-messages');
    while (chatMessages.children.length > 1) {
        chatMessages.removeChild(chatMessages.lastChild);
    }
    
    // Focus on input
    document.getElementById('user-input').focus();
}

function showNotification(message, type = 'success') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create new notification
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Auto hide after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
}