// Profile functionality
document.addEventListener('DOMContentLoaded', function() {
    initializeProfile();
});

function initializeProfile() {
    // Check if user is logged in
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    if (!currentUser) {
        window.location.href = 'login.html';
        return;
    }
    
    // Load profile data
    loadProfileData(currentUser);
    
    // Load user statistics
    loadUserStatistics();
}

function loadProfileData(currentUser) {
    // Update basic profile information
    document.getElementById('profile-name').textContent = `${currentUser.firstName} ${currentUser.lastName}`;
    document.getElementById('profile-email').textContent = currentUser.email;
    
    document.getElementById('info-name').textContent = `${currentUser.firstName} ${currentUser.lastName}`;
    document.getElementById('info-email').textContent = currentUser.email;
    document.getElementById('info-joined').textContent = new Date(currentUser.joinedAt).toLocaleDateString();
    document.getElementById('info-level').textContent = currentUser.learningLevel || 'Intermediate';
    
    // Load user preferences
    const userProfile = JSON.parse(localStorage.getItem('userProfile') || '{}');
    
    document.getElementById('pref-time').textContent = userProfile.dailyStudyTime || '2 hours';
    document.getElementById('pref-style').textContent = userProfile.learningStyle || 'Visual';
    document.getElementById('pref-reminders').textContent = userProfile.remindersEnabled ? 'Enabled' : 'Disabled';
    document.getElementById('pref-subjects').textContent = Array.isArray(userProfile.preferredSubjects) ? 
        userProfile.preferredSubjects.join(', ') : 'Programming, Data Science';
    
    // Load learning goals
    loadLearningGoals(userProfile.learningGoals);
}

function loadUserStatistics() {
    const userCourses = JSON.parse(localStorage.getItem('userCourses') || '[]');
    const userStats = JSON.parse(localStorage.getItem('userStats') || '{}');
    
    document.getElementById('stat-courses').textContent = userCourses.length;
    document.getElementById('stat-hours').textContent = Math.floor(userStats.totalHours || 0);
}

function loadLearningGoals(goals) {
    const goalsContainer = document.getElementById('learning-goals');
    
    if (!goals || goals.length === 0) {
        goals = [
            { title: "Complete Python Course", progress: 45, deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() },
            { title: "Learn Web Development", progress: 20, deadline: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString() },
            { title: "Build Portfolio Projects", progress: 10, deadline: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString() }
        ];
    }
    
    goalsContainer.innerHTML = '';
    
    goals.forEach(goal => {
        const goalCard = document.createElement('div');
        goalCard.className = 'goal-card';
        goalCard.innerHTML = `
            <h4>${goal.title}</h4>
            <p>Target: ${new Date(goal.deadline).toLocaleDateString()}</p>
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${goal.progress}%"></div>
            </div>
            <small>${goal.progress}% complete</small>
        `;
        goalsContainer.appendChild(goalCard);
    });
}

function editProfile() {
    // In a real app, this would open an edit modal
    // For now, we'll redirect to a simple edit page or show a message
    showNotification('Profile editing feature coming soon!', 'info');
}

function showNotification(message, type = 'success') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create new notification
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Auto hide after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
}