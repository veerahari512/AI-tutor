// Dashboard functionality
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    if (!currentUser) {
        window.location.href = 'login.html';
        return;
    }
    
    // Update user name
    document.getElementById('student-name').textContent = currentUser.firstName || 'Student';
    
    // Initialize dashboard data
    initializeDashboard();
});

function initializeDashboard() {
    // Update progress circles based on user data
    updateProgressCircles();
    
    // Load user courses
    loadUserCourses();
    
    // Update statistics
    updateStatistics();
}

function updateProgressCircles() {
    // In a real app, this would fetch data from an API
    // For now, we'll use static data
    const progressData = {
        overall: 75,
        python: 60,
        javascript: 85
    };
    
    const circles = document.querySelectorAll('.progress-circle');
    circles.forEach((circle, index) => {
        const progress = Object.values(progressData)[index];
        circle.style.background = `conic-gradient(var(--primary-color) 0% ${progress}%, #eee ${progress}% 100%)`;
        circle.querySelector('span').textContent = `${progress}%`;
    });
}

function loadUserCourses() {
    // In a real app, this would fetch from an API
    // For now, we'll use static data
    const userCourses = [
        { name: 'Python Programming', icon: 'fab fa-python', description: 'Beginner to Advanced', progress: 60 },
        { name: 'JavaScript', icon: 'fab fa-js-square', description: 'Web Development', progress: 85 },
        { name: 'Data Science', icon: 'fas fa-database', description: 'Python & Machine Learning', progress: 30 }
    ];
    
    const coursesList = document.querySelector('.courses-list');
    coursesList.innerHTML = '';
    
    userCourses.forEach(course => {
        const courseItem = document.createElement('div');
        courseItem.className = 'course-item';
        courseItem.innerHTML = `
            <div class="course-icon">
                <i class="${course.icon}"></i>
            </div>
            <div class="course-info">
                <h4>${course.name}</h4>
                <p>${course.description}</p>
            </div>
            <div class="course-progress">
                <div class="course-progress-bar">
                    <div class="course-progress-fill" style="width: ${course.progress}%"></div>
                </div>
                <div class="course-progress-text">${course.progress}% complete</div>
            </div>
        `;
        coursesList.appendChild(courseItem);
    });
}

function updateStatistics() {
    // In a real app, this would fetch from an API
    // For now, we'll use static data
    const stats = {
        hours: 12,
        quizScore: 85,
        topics: 24,
        streak: 5
    };
    
    document.querySelectorAll('.stat-value').forEach((stat, index) => {
        stat.textContent = Object.values(stats)[index] + (index === 1 ? '%' : '');
    });
}